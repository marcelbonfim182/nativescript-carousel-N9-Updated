import { addWeakEventListener, booleanConverter, Color, GridLayout, Label, ObservableArray, Property, removeWeakEventListener, StackLayout, Utils, } from '@nativescript/core';
export class CarouselUtil {
}
CarouselUtil.debug = false;
export class Log {
    static D(...args) {
        if (CarouselUtil.debug === true) {
            console.log('NativeScript-Carousel DEBUG: ', ...args);
            console.log('---------------------------------------------------');
        }
    }
}
export class CarouselCommon extends GridLayout {
    constructor() {
        super();
    }
    set debug(value) {
        CarouselUtil.debug = value;
    }
    get debug() {
        return CarouselUtil.debug;
    }
    _getDefaultItemContent(index) {
        const lbl = new Label();
        lbl.bind({
            targetProperty: 'text',
            sourceProperty: '$value',
        });
        return lbl;
    }
}
CarouselCommon.pageChangedEvent = 'pageChanged';
CarouselCommon.pageTappedEvent = 'pageTapped';
CarouselCommon.pageScrollingEvent = 'pageScrolling';
CarouselCommon.pageScrollStateChangedEvent = 'pageScrolled';
export class CarouselItem extends StackLayout {
    constructor() {
        super();
    }
    onLoaded() {
        super.onLoaded();
    }
}
export var knownTemplates;
(function (knownTemplates) {
    knownTemplates.itemTemplate = 'itemTemplate';
})(knownTemplates || (knownTemplates = {}));
export const debugProperty = new Property({
    name: 'debug',
    defaultValue: false,
    valueConverter: booleanConverter,
    valueChanged: (view, oldValue, newValue) => {
        CarouselUtil.debug = newValue;
    },
});
debugProperty.register(CarouselCommon);
export const itemTemplateProperty = new Property({
    name: 'itemTemplate',
    affectsLayout: true,
    valueChanged: (view, oldValue, newValue) => {
        view.refresh(true);
    },
});
itemTemplateProperty.register(CarouselCommon);
export const itemsProperty = new Property({
    name: 'items',
    affectsLayout: true,
    valueChanged: onItemsChanged,
});
itemsProperty.register(CarouselCommon);
export const selectedPageProperty = new Property({
    name: 'selectedPage',
    defaultValue: 0,
    valueConverter: (value) => {
        return +value;
    },
    valueChanged: (view, oldValue, newValue) => {
        view.selectedPage = newValue;
    },
});
selectedPageProperty.register(CarouselCommon);
export const showIndicatorProperty = new Property({
    name: 'showIndicator',
    defaultValue: true,
    valueConverter: booleanConverter,
    valueChanged: (view, oldValue, newValue) => {
        view.showIndicator = newValue;
    },
});
showIndicatorProperty.register(CarouselCommon);
export const indicatorColorProperty = new Property({
    name: 'indicatorColor',
    equalityComparer: Color.equals,
    valueConverter: (value) => {
        return new Color(value);
    },
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorColor = newValue;
    },
});
indicatorColorProperty.register(CarouselCommon);
export const indicatorColorUnselectedProperty = new Property({
    name: 'indicatorColorUnselected',
    equalityComparer: Color.equals,
    valueConverter: (value) => {
        return new Color(value);
    },
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorColorUnselected = newValue;
    },
});
indicatorColorUnselectedProperty.register(CarouselCommon);
export const indicatorOffsetProperty = new Property({
    name: 'indicatorOffset',
    defaultValue: '0,0',
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorOffset = newValue;
    },
});
indicatorOffsetProperty.register(CarouselCommon);
export const autoPagingIntervalProperty = new Property({
    name: 'autoPagingInterval',
    defaultValue: 0,
    valueConverter: (value) => {
        return +value;
    },
    valueChanged: (view, oldValue, newValue) => {
        view.autoPagingInterval = newValue;
    },
});
autoPagingIntervalProperty.register(CarouselCommon);
export const finiteProperty = new Property({
    name: 'finite',
    valueConverter: booleanConverter,
    valueChanged: (view, oldValue, newValue) => {
        view.finite = newValue;
    },
});
finiteProperty.register(CarouselCommon);
export const bounceProperty = new Property({
    name: 'bounce',
    valueConverter: booleanConverter,
    valueChanged: (view, oldValue, newValue) => {
        view.bounce = newValue;
    },
});
bounceProperty.register(CarouselCommon);
export const scrollEnabledProperty = new Property({
    name: 'scrollEnabled',
    valueConverter: booleanConverter,
    valueChanged: (view, oldValue, newValue) => {
        view.scrollEnabled = newValue;
    },
});
scrollEnabledProperty.register(CarouselCommon);
export const indicatorAnimationProperty = new Property({
    name: 'indicatorAnimation',
    affectsLayout: true,
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorAnimation = newValue;
    },
});
indicatorAnimationProperty.register(CarouselCommon);
export const indicatorAnimationDurationProperty = new Property({
    name: 'indicatorAnimationDuration',
    affectsLayout: true,
    valueConverter: (value) => {
        return +value;
    },
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorAnimationDuration = newValue;
    },
});
indicatorAnimationDurationProperty.register(CarouselCommon);
export const indicatorAlignmentProperty = new Property({
    name: 'indicatorAlignment',
    defaultValue: 'BOTTOM',
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorAlignment = newValue.toUpperCase();
    },
});
indicatorAlignmentProperty.register(CarouselCommon);
export const indicatorRadiusProperty = new Property({
    name: 'indicatorRadius',
    affectsLayout: true,
    valueConverter: (value) => {
        return +value;
    },
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorRadius = newValue;
    },
});
indicatorRadiusProperty.register(CarouselCommon);
export const indicatorPaddingProperty = new Property({
    name: 'indicatorPadding',
    affectsLayout: true,
    valueConverter: (value) => {
        return +value;
    },
    valueChanged: (view, oldValue, newValue) => {
        view.indicatorPadding = newValue;
    },
});
indicatorPaddingProperty.register(CarouselCommon);
function onItemsChanged(view, oldValue, newValue) {
    if (oldValue instanceof ObservableArray) {
        removeWeakEventListener(oldValue, ObservableArray.changeEvent, view.refresh, view);
    }
    if (newValue instanceof ObservableArray) {
        addWeakEventListener(newValue, ObservableArray.changeEvent, view.refresh, view);
    }
    if (!Utils.isNullOrUndefined(view.items) && Utils.isNumber(view.items.length)) {
        view.refresh(false);
    }
}
export var IndicatorAnimation;
(function (IndicatorAnimation) {
    IndicatorAnimation["NONE"] = "NONE";
    IndicatorAnimation["COLOR"] = "COLOR";
    IndicatorAnimation["SLIDE"] = "SLIDE";
    IndicatorAnimation["WORM"] = "WORM";
    IndicatorAnimation["FILL"] = "FILL";
    IndicatorAnimation["SCALE"] = "SCALE";
    IndicatorAnimation["SCALE_DOWN"] = "SCALE_DOWN";
    IndicatorAnimation["THIN_WORM"] = "THIN_WORM";
    IndicatorAnimation["DROP"] = "DROP";
    IndicatorAnimation["SWAP"] = "SWAP";
})(IndicatorAnimation || (IndicatorAnimation = {}));
//# sourceMappingURL=carousel.common.js.map