# NativeScript 9 compatibility patch

This package keeps the public plugin name (`nativescript-carousel`) and XML namespace unchanged.

Android changes:

- Replaced the removed Gradle `compile` dependency configuration.
- Replaced the old JCenter/Bintray dependency `com.romandanylyk:pageindicatorview:1.0.3` with the compatible Maven Central fork `tech.abd3lraouf:pageindicatorview:1.0.3`.

No Carousel XML tags, event names, JavaScript API, or iOS files were changed.
